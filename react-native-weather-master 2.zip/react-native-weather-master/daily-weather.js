import React, { Component } from 'react';
import DayTemp from './dayTemp';

export default (props) => {
  const data = props.daily.data;
  const dayTemps = data.map((item, index) => {
    return <DayTemp />
  })
  return (
    <View>
      {dayTemps}
    </View>
  );
}
